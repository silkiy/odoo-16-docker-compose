# -*- coding: utf-8 -*-

from . import models
from . import training_course
from . import instruktur
from . import wilayah
from . import res_partner_inherit
from . import peserta
